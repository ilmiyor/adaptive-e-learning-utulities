<?php

/**
 * This is the model class for table "{{lesslet}}".
 *
 * The followings are the available columns in table '{{lesslet}}':
 * @property integer $id
 * @property integer $user_id
 * @property integer $concept_id
 * @property string $definition
 * @property string $example
 * @property string $test
 * @property string $image_example
 * @property string $correct_answer
 * @property integer $score
 * @property string $created_at
 * @property string $updated_at
 */
class Lesslet extends CActiveRecord
{
	public $image_example;
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return '{{lesslet}}';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('user_id, concept_id, definition, example, test, correct_answer', 'required'),
			array('user_id, concept_id, score', 'numerical', 'integerOnly'=>true),
			// array('image_example','file',
			// 	'types'=>'jpg, gif, png' ,
			// 	'maxFiles'=>'1',
			// 	'maxSize'=>50000,
			// 	'tooLarge'=>'Fayl hajmi 50 kb dan kichik bolishi kerak'
			// ),
			array('correct_answer', 'length', 'max'=>45),
			array('created_at, updated_at', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, user_id, concept_id, definition, example, test, image_example, correct_answer, score, created_at, updated_at', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'user_id' => 'User',
			'concept_id' => 'Tushuncha',
			'definition' => 'Izoh',
			'example' => 'Misol',
			'test' => 'Test',
			'image_example' => 'Image Example',
			'correct_answer' => 'To\'ri javob',
			'score' => 'Score',
			'created_at' => 'Created At',
			'updated_at' => 'Updated At',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id);
		$criteria->compare('user_id',$this->user_id);
		$criteria->compare('concept_id',$this->concept_id);
		$criteria->compare('definition',$this->definition,true);
		$criteria->compare('example',$this->example,true);
		$criteria->compare('test',$this->test,true);
		$criteria->compare('image_example',$this->image_example,true);
		$criteria->compare('correct_answer',$this->correct_answer,true);
		$criteria->compare('score',$this->score);
		$criteria->compare('created_at',$this->created_at,true);
		$criteria->compare('updated_at',$this->updated_at,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Lesslet the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
