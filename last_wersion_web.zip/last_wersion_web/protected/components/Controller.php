<?php
/**
 * Controller is the customized base controller class.
 * All controller classes for this application should extend from this base class.
 */

class Controller extends CController
{
	public function init(){
		// register class paths for extension captcha extended
		Yii::$classMap = array_merge( Yii::$classMap, array(
			'CaptchaExtendedAction' => Yii::getPathOfAlias('ext.captchaExtended').DIRECTORY_SEPARATOR.'CaptchaExtendedAction.php',
			'CaptchaExtendedValidator' => Yii::getPathOfAlias('ext.captchaExtended').DIRECTORY_SEPARATOR.'CaptchaExtendedValidator.php'
		));
	}

	/**
	 * @var string the default layout for the controller view. Defaults to '//layouts/column1',
	 * meaning using a single column layout. See 'protected/views/layouts/column1.php'.
	 */
	public $layout='//layouts/column1';
	/**
	 * @var array context menu items. This property will be assigned to {@link CMenu::items}.
	 */
	public $menu=array();
	public $menu_topics=array();
	public $curTopicId;
	public $shareCont;
	/**
	 * @var array the breadcrumbs of the current page. The value of this property will
	 * be assigned to {@link CBreadcrumbs::links}. Please refer to {@link CBreadcrumbs::links}
	 * for more details on how to specify this property.
	 */
	public $breadcrumbs=array();
	public function score()
	{
		// $model = Actions::model()->findByAttributes('user_id', Yii::app()->user->getId());
		if (!empty($ui=Yii::app()->user->id)) {
			$scoreObj = $this->userActionScores();
			$s = 0;
			foreach ($scoreObj as $score) {
				$s = $s+$score;
			}
			if (!(count($scoreObj)==0)) {
				$overallScore = ($s/count($scoreObj)<=5)?$s/count($scoreObj):5;
			}else $overallScore=false;

			return $overallScore;
		}else {
			return false;
		}
	}

	// Find all lesslets that the current user created
	//and return two arrays which have lesslet and concept ids
	public function getLesConIds()
	{
		if (!empty(Yii::app()->user->id)) {
			$uid = Yii::app()->user->id;
			$lesslets = Lesslet::model()->findAll('user_id='.$uid);
			$lesIds = array();
			$conIds = array();
			foreach ($lesslets as $value) {
				 $lesIds[]=$value->attributes['id'];
				 $conIds[]=$value->attributes['concept_id'];
			}
			return array(
				'lesIds' => $lesIds,
				'conIds' => $conIds,
			);
		}else {
			return false;
		}
	}

	public function highScoreLesslet($conId,$lesScore=0){
		$criteria = new CDbCriteria();
		$criteria->select="t.*";
		$criteria->join="left join (select sum(action) as summa, t.* from tbl_actions as t group by lesslet_id order by summa DESC) as ls on (t.id=ls.lesslet_id)";
		$criteria->condition = "t.concept_id=".$conId." and ls.summa>".$lesScore;
		$criteria->limit = 3;
		return $testData = Lesslet::model()->findAll($criteria);
	}

	// Returns an array with summed scores for each lesslet the current user created
	public function userActionScores(){
		$getLesConIds = $this->getLesConIds();
		$lessletScores = array();
			foreach ($getLesConIds['lesIds'] as $lesId) {
				$lessletScores[] = $this->getLessletScore($lesId)['summa'];
			}
		return $lessletScores;
	}

	//Return a single Concept's title
	public function getConceptName($conId)
	{
		$conceptId = Algcon::model()->findByPk($conId)->getAttribute('title');
		return $conceptId;
	}

	public function getTopic($conId=1,$topId=''){

		$topicId = Algcon::model()->findByPk($conId)->getAttribute('algtop_id');
		return Algtop::model()->findByPk($topId?$topId:intval($topicId))->getAttribute('title');
	}

	//Returns a list of Topic names
	public function getTopics(){
		return Algtop::model()->findAll();
	}

	public function getLessletScore($lesId){
		$criteria = new CDbCriteria();
		$criteria->select="sum(action) as summa";
		$criteria->condition="lesslet_id=:lid";
		$criteria->params = array('lid'=>$lesId);
		return Actions::model()->find($criteria);

	}
}
