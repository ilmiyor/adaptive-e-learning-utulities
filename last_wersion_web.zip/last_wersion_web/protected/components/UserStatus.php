<?php

class UserStatus extends UserIdentity
{
	public function calcAction()
	{
		$user_id = Yii::app()->user->id;
		$criteria = new CDbCriteria();
		$criteria->select="sum(action) as summa";
		$criteria->condition = "user_id=:uid";
		$criteria->params = array('uid'=>$user_id);
		$model=Actions::model()->find($criteria);
		$this->setState('Ldata', 'assa');

	}
}
