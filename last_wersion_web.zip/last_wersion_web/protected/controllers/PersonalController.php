<?php

class personalController extends Controller
{
	public $isKnown;
	public $layout='//layouts/column2_3';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		/* @var $c Concepts */
		if (isset($_GET['id'])) {
			$c = Concepts::model()->findByPk($_GET['id']);
			$r = User::model()->findAll(array(
				'condition'=>'role=0',
				// 'params'=>array(
				// 	':crs'=>$c->course,
				)
			);
			$users = CHtml::listData($r, 'username','username');
			$users[]='admin';
		}
		else {
			$users=array('admin', 'ilmiyor');
		}
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('student'),
				'users'=>array('*'),
			),
			// array('allow', // allow authenticated user to perform 'create' and 'update' actions
			// 	'actions'=>array('create','update'),
			// 	'users'=>array('@'),
			// ),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('teacher'),
				'users'=> $users,//array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}


	//Returns the current user's learning style (input)
	public function userInputLS(){
			$userInputLS = Input::model()->find("user_id=".Yii::app()->user->id);
			if (empty($userInputLS)) {
				$this->isKnown=false;
				return null;
			}
			return $userInputLS->getAttribute('input');
	}
	//Returns the list of  users' id witch matcher the current user's LSinput
	public function findAllMatchingLesslets($limit=-1){
		$userInputLS = $this->userInputLS();
		if (!($userInputLS===null)) {
			$this->isKnown=true;
				$middlePole = [-1,0,1];//101
				$rightPole = 	[2,3,4,5,6];//87     		= 101+87+130 = 318
				$leftPole = 	[-6,-5,-4,-3,-2]; //130
			$userInputLS = in_array($userInputLS,$leftPole)?$leftPole:(in_array($userInputLS,$middlePole)?$middlePole:$rightPole);

			$criteria = new CDbCriteria();
			$criteria->select= "*";
	 	 	$criteria->join = "right join (select t.* from tbl_input as t where t.input>=".min($userInputLS)." AND t.input<=".max($userInputLS).") as myin on (myin.user_id=t.user_id)
	 											right join (select sum(action) as summa, t.* from tbl_actions as t group by lesslet_id order by summa DESC) as action on (t.id=action.lesslet_id)";
			$criteria->condition="t.user_id!=:userid";
			$criteria->params = array('userid'=>Yii::app()->user->id);
			$criteria->addInCondition('concept_id',array_unique($this->getLesConIds()['conIds']));
			// $criteria->condition = "t.concept_id=".$conId." and ls.summa>".$lesScore;
			$dataProvider = new CActiveDataProvider('Lesslet', array('criteria'=>$criteria,'pagination'=>array(
	        'pageSize'=>$limit,
	    ),
	    ));
			// return Lesslet::model()->findAll($criteria);
			return $dataProvider;
		}else {
			return $this->HighScoreLesslets($limit);
		}
	}

	public function HighScoreLesslets($limit=-1){
		$criteria = new CDbCriteria();
		$criteria->select= "*";
		$criteria->join = "right join (select sum(action) as summa, t.* from tbl_actions as t group by lesslet_id order by summa DESC) as action on (t.id=action.lesslet_id)";
		$criteria->condition="t.user_id!=:userid";
		$criteria->params = array('userid'=>Yii::app()->user->id);
		$criteria->addInCondition('concept_id',array_unique($this->getLesConIds()['conIds']));
		$dataProvider = new CActiveDataProvider('Lesslet', array('criteria'=>$criteria,'pagination'=>array('pageSize'=>$limit,),
    ));
		// return Lesslet::model()->findAll($criteria);
		return $dataProvider;
	}

	public function NewLesslets($limit=-1){
		$criteria = new CDbCriteria();
		$criteria->select= "*";
		$criteria->order="created_at DESC";
		$criteria->addInCondition('concept_id',array_unique($this->getLesConIds()['conIds']));
		$criteria->addNotInCondition('t.user_id',array(Yii::app()->user->id));
		$dataProvider = new CActiveDataProvider('Lesslet', array('criteria'=>$criteria,'pagination'=>array('pageSize'=>$limit))
    );
		// return Lesslet::model()->findAll($criteria);
		return $dataProvider;
	}

	public function actionStudent($limit=3, $params='')
	{

		$dataProviderLS = $this->findAllMatchingLesslets($params=='ls'?$limit:3);
		$dataProviderHigh = $this->HighScoreLesslets($params=='high'?$limit:3);
		$dataProviderNew = $this->NewLesslets($params=='new'?$limit:3);
		// echo "<pre>";var_dump($dataProvider);exit;
		$getLesConIds = $this->getLesConIds();
		$topics=$this->getTopics();
		if ($getLesConIds) {
			$this->render('student',array(
				'dataProviderLS'=>$dataProviderLS,
				'dataProviderHigh'=>$dataProviderHigh,
				'dataProviderNew'=>$dataProviderNew,
				'lessletActions' => $this->userActionScores(),
				'conIds'=>$getLesConIds['conIds'],
				'lesIds'=>$getLesConIds['lesIds'],
				'topics'=>$topics,
			));
		}else {
			$this->redirect('/algcon/index');
		}
	}

	//Returns data for topic ribbon
	public function topicRibbon($topicId){
		$ConIdsByATopic = $this->ConIdsByATopic($topicId);
		$userCreatedLessletsByAconcept = $this->nContributedCons($ConIdsByATopic);
		$scoreByTopic = $userCreatedLessletsByAconcept?$this->scoreByTopic($userCreatedLessletsByAconcept):'';
		return array(
			'nCons' => count($ConIdsByATopic),
			'lessIdsByConcept'=> count($userCreatedLessletsByAconcept),
			'scoreByTopic'=>$scoreByTopic,
		);

	}

	//Returns score for a topic
	public function scoreByTopic($userCreatedLessletsByAconcept){
		// $userCreatedLessletsByAconcept contains contributed concept ids as key and his lesslets as value
		$summa = 0;
		foreach ($userCreatedLessletsByAconcept as $key => $con) {

			$criteria = new CDbCriteria();
			$criteria->select="sum(action) as summa";
			$criteria->condition = "lesslet_id=:lId";
			$criteria->params = array('lId'=>$con[0]['id']);
			$summa+=Actions::model()->findAll($criteria)[0]['summa'];
		}
		return $summa;
	}
	//Returns the number of concepts which this user contributed
	private function nContributedCons($ConIdsByATopic){
		$lessIdsByConcept = array();
		foreach ($ConIdsByATopic as $key => $conId) {
			$criteria = new CDbCriteria();
			$criteria->select="id";
			$criteria->condition = "user_id=:uid AND concept_id=:conId";
			$criteria->params = array('uid'=>Yii::app()->user->id, 'conId'=>$conId['id']);
			$model=lesslet::model()->findAll($criteria);
			// echo "<pre>";var_dump(lesslet::model()->findAll($criteria)?lesslet::model()->findAll($criteria):'');
			if (!empty($model)) {
				$lessIdsByConcept[$conId['id']]=$model;
			}
		}
		return $lessIdsByConcept;
	}

	//Returns concept ids available in a topic
	private function ConIdsByATopic($topicId){
		$concepts = Algcon::model()->findAll(array(
                        'select'=>'id',
                        'condition'=>'algtop_id='.$topicId
                    ));
		return $concepts;
	}

	//Returns lesslets under $activeTopic
	 public function lessletsByATopic($activeTopic, $method, $limited=true){
		 $criteria = new CDbCriteria();
		 $criteria->select="t.*";
		 $criteria->join="left join (select id, algtop_id from tbl_algcon t) as con on (t.concept_id=con.id)";
		 $criteria->condition = "algtop_id=:activeTopic";
		 $criteria->params = array('activeTopic'=>$activeTopic);
		 $criteria->limit=$limited?3:-1;
		 $model=lesslet::model()->findAll($criteria);
		 return $model;

		 // SELECT *
		 // FROM tbl_lesslet les
		 // LEFT JOIN tbl_algcon con
		 // ON les.concept_id=con.id
		 // WHERE con.algtop_id=3
		 // LIMIT 3

		 		 // $criteria = new CDbCriteria();
		     // $criteria->select="ls.sm, t.*";
		     // $criteria->join="left join (select sum(action) as sm, t.* from tbl_actions as t group by lesslet_id order by sm DESC) as ls on (t.id=ls.lesslet_id)";
		     // $criteria->order = 'ls.sm desc';
				 //
				 // select * from tbl_lesslet l
					// left join (select sum(action) as sm, t.* from tbl_actions as t group by lesslet_id order by sm DESC) as ls on (l.id=ls.lesslet_id)
					// order by ls.sm desc
	 }

	 public function actionTeacher(){

		 $this->render("teacher", array('data'=>'Feed for teacher'));
	 }
	 private function test(){

	 }

}
