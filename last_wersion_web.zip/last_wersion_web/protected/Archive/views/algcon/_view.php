<?php
/* @var $this AlgconController */
/* @var $data Algcon */

?>
<div class="view">
	<h1><?php echo $data->title ?></h1>
	<?php echo $data->body ?> <br>
	| <a href="<?=Yii::app()->createUrl('lesslet/index',array('concept_id'=>$data->id, 'concept_title'=>$data->title)) ?>">Lesslet</a> |

	<?php echo CHtml::link(CHtml::encode("Change"), array('update', 'id'=>$data->id),array('style'=>Yii::app()->user->isGuest?'display: none':'')); ?>
	<br />


</div>
