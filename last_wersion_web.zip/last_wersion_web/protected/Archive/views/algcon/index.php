<?php
/* @var $this AlgconController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Algcons',
);

foreach ($topIds as $topId) {
	$menu[]=array(
		'label'=>$topId->title,
		'url'=>array('algcon/index','id'=>$topId->id)
	);
	$this->menu = $menu;
}
?>
<?php
$this->widget('zii.widgets.CListView', array(
'dataProvider'=>$dataProvider,
'itemView'=>'_view',
'template'=>"{pager}\n{items}\n{pager}",
'pager'=> array('datas'=>$pager),
));

// echo $dataProvider->data;
?>
