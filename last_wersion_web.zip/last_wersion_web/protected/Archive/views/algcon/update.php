<?php
/* @var $this AlgconController */
/* @var $model Algcon */

$this->breadcrumbs=array(
	'Algcons'=>array('index'),
	$model->title=>array('view','id'=>$model->id),
	'Update',
);

$this->menu=array(
	array('label'=>'List Algcon', 'url'=>array('index')),
	array('label'=>'Create Algcon', 'url'=>array('create')),
	array('label'=>'View Algcon', 'url'=>array('view', 'id'=>$model->id)),
	array('label'=>'Manage Algcon', 'url'=>array('admin')),
);
?>

<h1>Update Algcon <?php echo $model->id; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>