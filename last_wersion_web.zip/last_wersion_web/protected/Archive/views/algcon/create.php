<?php
/* @var $this AlgconController */
/* @var $model Algcon */

$this->breadcrumbs=array(
	'Algcons'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List Algcon', 'url'=>array('index')),
	array('label'=>'Manage Algcon', 'url'=>array('admin')),
);
?>

<h1>Create Algcon</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>