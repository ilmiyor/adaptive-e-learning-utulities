<?php
/* @var $this AlgconController */
/* @var $model Algcon */

$this->breadcrumbs=array(
	'Algcons'=>array('index'),
	$model->title,
);

$this->menu=array(
	array('label'=>'List Algcon', 'url'=>array('index')),
	array('label'=>'Create Algcon', 'url'=>array('create')),
	array('label'=>'Update Algcon', 'url'=>array('update', 'id'=>$model->id)),
	array('label'=>'Delete Algcon', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->id),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage Algcon', 'url'=>array('admin')),
);
?>

<h1>View Algcon #<?php echo $model->id; ?></h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		'id',
		'algtop_id',
		'order',
		'title',
		'body',
		'created_at',
		'updated_at',
	),
)); ?>
