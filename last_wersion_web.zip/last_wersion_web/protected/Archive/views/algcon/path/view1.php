<?php
echo "view1";
 ?>
