<?php
/* @var $this LessletController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Lesslets',
);

$this->menu=array(
	array('label'=>'Create Lesslet', 'url'=>array('create', 'cid'=>$lessletData['concept_id'])),
	array('label'=>'Manage Lesslet', 'url'=>array('admin')),
);
?>
<h1>Lesslets</h1>

<?php

// echo"<pre>"; print_r(); echo"</pre>";

$this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
	'emptyText' => 'There is no lesslet for <b>'.$lessletData['concept_title'].'</b>, Please create one.',
)); ?>
