<?php
/* @var $this LessletController */
/* @var $model Lesslet */

$this->breadcrumbs=array(
	'Lesslets'=>array('index'),
	$model->id=>array('view','id'=>$model->id),
	'Update',
);

$this->menu=array(
	array('label'=>'List Lesslet', 'url'=>array('index')),
	array('label'=>'Create Lesslet', 'url'=>array('create')),
	array('label'=>'View Lesslet', 'url'=>array('view', 'id'=>$model->id)),
	array('label'=>'Manage Lesslet', 'url'=>array('admin')),
);
?>

<h1>Update Lesslet <?php echo $model->id; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>