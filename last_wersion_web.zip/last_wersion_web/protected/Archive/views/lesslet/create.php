<?php
/* @var $this LessletController */
/* @var $model Lesslet */

$this->breadcrumbs=array(
	'Lesslets'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List Lesslet', 'url'=>array('index')),
	array('label'=>'Manage Lesslet', 'url'=>array('admin')),
);
?>

<h1>Lesslet yaratish</h1>

<?php
$model->concept_id = $cid;
$this->renderPartial('_form', array('model'=>$model)); ?>
