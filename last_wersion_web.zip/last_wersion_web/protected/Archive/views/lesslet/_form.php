<?php
/* @var $this LessletController */
/* @var $model Lesslet */
/* @var $form CActiveForm */
?>
<div class="form">
<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'lesslet-form',
	// Please note: When you enable ajax validation, make sure the corresponding
	// controller action is handling ajax validation correctly.
	// There is a call to performAjaxValidation() commented in generated controller code.
	// See class documentation of CActiveForm for details on this.
	'enableAjaxValidation'=>false,
	'htmlOptions'=>array('enctype'=>'multipart/form-data'),// This is required for file upload
)); ?>

<h1 style="color:red"><?php echo Yii::app()->user->getFlash('error'); ?></h1>
	<p class="note"> <span class="required">*</span> li joylar to'ldirilishi shart.</p>

	<?php echo $form->errorSummary($model); ?>

	<div class="row">
		<?php echo $form->labelEx($model,'concept_id'); ?>
		<?php echo $form->dropDownList($model,'concept_id',CHtml::listData(Algcon::model()->findAll("id='$model->concept_id'"),'id','title')); ?>
		<?php echo $form->error($model,'concept_id'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'definition'); ?>
		<?php echo $form->textArea($model,'definition',array('rows'=>6, 'cols'=>50)); ?>
		<?php echo $form->error($model,'definition'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'example'); ?>
		<?php echo $form->textArea($model,'example',array('rows'=>6, 'cols'=>50)); ?>
		<?php echo $form->error($model,'example'); ?>
			<label for="image_example">Rasm joylash:</label>
			        <?php echo $form->fileField($model,'image_example',array('id'=>'file')); ?>
	</div>
	<div class="row">
		<?php echo $form->labelEx($model,'test'); ?>
		<?php echo $form->textArea($model,'test',array('rows'=>6, 'cols'=>50)); ?>
		<?php echo $form->error($model,'test'); ?>
	</div>

	<div class="row">
		<?php echo $form->labelEx($model,'correct_answer'); ?>
		<?php echo $form->textField($model,'correct_answer',array('size'=>45,'maxlength'=>45)); ?>
		<?php echo $form->error($model,'correct_answer'); ?>
	</div>

	<div class="row buttons">
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Yaratish' : 'Saqlash'); ?>
	</div>
<?php $this->endWidget(); ?>

</div><!-- form -->
