<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="CV">
    <title>AEHS</title>

    <link rel="stylesheet" href="https://unpkg.com/purecss@1.0.0/build/pure-min.css" integrity="sha384-" crossorigin="anonymous">

    <!--[if lte IE 8]>
        <link rel="stylesheet" href="https://unpkg.com/purecss@1.0.0/build/grids-responsive-old-ie-min.css">
    <![endif]-->
    <!--[if gt IE 8]><!-->
        <link rel="stylesheet" href="https://unpkg.com/purecss@1.0.0/build/grids-responsive-min.css">
    <!--<![endif]-->


        <!--[if lte IE 8]>
            <link rel="stylesheet" href="css/layouts/blog-old-ie.css">
        <![endif]-->
        <!--[if gt IE 8]><!-->
            <link rel="stylesheet" href="/css/layouts/blog.css">
        <!--<![endif]-->
</head>

<body>
  <nav style="text-align: right; margin-top: 20px;">
    | <a href="<?=Yii::app()->createUrl('algcon/index') ?>">Algorithms</a> |
  </nav>
<div id="layout" class="pure-g">
    <div class="sidebar pure-u-1 pure-u-md-1-4">
        <div class="header">
            <img class="pure-img" src="/images/rasm.jpg" alt="">
            <h1 class="brand-title">Doniyorbek</h1>
            <h2 class="brand-tagline">Ahmadaliev</h2>

            <nav class="nav">
                <ul class="nav-list">
                    <li class="nav-item">
                        <a class="pure-button" href="https://www.researchgate.net/profile/Doniyorbek_Ahmadaliev2">Researchgate</a>
                    </li>
                    <li class="nav-item">
                        <a class="pure-button" href="http://academia.edu">Academia</a>
                    </li>
                </ul>
            </nav>
        </div>
    </div>

    <div class="content pure-u-1 pure-u-md-3-4">
        <div>
            <!-- A wrapper for all the blog posts -->
            <div class="posts">
                <h1 class="content-subhead">Short description</h1>

                <!-- A single blog post -->
                <section class="post">
                    <header class="post-header">
                      <h2 class="post-title">Doniyorbek Ahmadaliev ( 多尼) </h2>
                    </header>

                    <div class="post-meta">
                        <p>
                      Studies at the School of information Science and Technologies <br>
                      Northeast Normal University <br>
                      No. 5268, Renmin Street, Changchun, Jilin province, 130024, China <br>
                      Phone: +86-155-4301-9050 <br>
                      Email: duon1124[at]nenu.edu.cn; ilmiyor[at]outlook.com <br>
                        </p>
                        <h2>Corriculum vitae</h2>
                        <p>
                          Doniyorbek Ahmadaliev, he is PhD student at Northeast Normal University. His research interests include adaptive web based systems, personalized e-learning, adaptive hypermedia. Research projects: adaptive educational hypermedia systems, dynamic detecting of user preferences and web-based user modeling. Prior to PhD, he closely worked with (web) software and hardware computer engineering at institutions in Uzbekistan. Also, he has two year university level teaching experience in his major.
                        </p>
                    </div>
                </section>
            </div>


              <h1 class="content-subhead">Education</h1>
              <section class="post">
                      <p class="post-meta">
                          <a href="http://www.nenu.edu.cn">Sep. 2016 - Present:</a> PhD student School of information Science and Technologies, Northeast Normal University (China) Program major: Education Information Science and Technology
                      </p>
                      <p class="post-meta">
                          <a href="http://nammqi.uz/">2006-2012: </a> B.S. and M.S. Namangan Engineering and Pedagogical Institute (Uzbekistan) Major: Education - Information Science and Technologies
                      </p>
              </section>

              <h1 class="content-subhead">Work Experience</h1>
              <section class="post">
                      <p class="post-meta">
                        <a href="https://adu.uz/">2018-present: </a> Teacher of Information technologies, Andijan State University (Uzbekistan)
                      </p>
                      <p class="post-meta">
                          <a href="https://adu.uz/">2012-2014:</a> Teacher of Information technologies, Andijan State University (Uzbekistan)
                      </p>
                      <p class="post-meta">
                          <a href="http://nammqi.uz/">2004-2012:</a> Software engineer at Computer Department, Namangan Engineering and Pedagogical Institute (Uzbekistan)
                      </p>
              </section>

              <h1 class="content-subhead">Publications (International journals)</h1>
              <section class="post">
                      <ul>
                        <li><b>Doniyorbek K. A.</b>, Medatov, A. A., Jo'rayev, M. M., & O'rinov, N. T. (2019). Adaptive educational hypermedia systems: an overview of current trend of adaptive content representation and sequencing. ISJ Theoretical & Applied Science, 03 (71), 58-61. Doi: <a href="https://dx.doi.org/10.15863/TAS.2019.03.71.7">https://dx.doi.org/10.15863/TAS.2019.03.71.7</a> </li>
                        <li><b>Doniyorbek K. A.</b>,(2018), A Web based instrument to initiate learning style: an interactive questionnaire instrument, International, Journal of Emerging Technologies in Learning, Vol. 13, No. 12 <a href="https://doi.org/10.3991/ijet.v13i12.8725">https://doi.org/10.3991/ijet.v13i12.8725</a> </li>
                        <li>J. Michael Spector,SLFG(<b>Anmadaliev Doniyorbek</b>, Abdelmoiz Ramadan), 2018, Smart learning futures: a report from the 3rd US-China smart education conference, Smart Learning Environments, 5(5) <a href="https://doi.org/10.1186/s40561-018-0054-1">https://doi.org/10.1186/s40561-018-0054-1</a> </li>
                        <li><b>Doniyorbek K. A.</b>, 2015, Web 2.0 tools – as a way direction for students toward the trusted and right sources while teaching a language online, IJARCET, 4 (6)</li>
                        <li><b>Doniyorbek K. A.</b>, 2015, Analyzing behavioral activities among the multilingual big-data on the complex network with the help of suggested potential monitoring: Altai family languages in China, IJARCET, 4 (6) </li>
                        <li>А.М.Расулов, <b>Doniyorbek K. A.</b>, 2014, Processes of Forming of Nano-Structures during Concretion of Clusters to Surface of Crystalls with the Helps of Computer Modeling, АВТОМАТИКА И ПРОГРАММНАЯ ИНЖЕНЕРИЯ, 1(7), <a href="http://www.jurnal.nips.ru/sites/default/files/%D0%90%D0%98%D0%9F%D0%98-1-2014-10.pdf">http://www.jurnal.nips.ru/sites/default/files/%D0%90%D0%98%D0%9F%D0%98-1-2014-10.pdf</a> </li>
                      </ul>
              </section>
              <h1 class="content-subhead">Proceedings (International conferences)</h1>
              <section class="post">
                      <ul>
                        <li><b>Doniyorbek K. A.</b>, 2019, An adaptive activity sequencing instrument to enhance e-learning: an integrated application of overlay user model and mathematical programming on the Web, <i>2019 International Conference on Computer and Information Sciences (ICCIS), April 3 – 4, Jouf University, Aljouf, Kingdom of Saudi Arabia</i> </li>
            <li><b>Doniyorbek K. A.</b>, 2018, Enhancing adaptiveness for e-learning system by integrating with a Web- based instrument to detect learning style, <i>The 11th International Conference on Ubi-Media Computing and Workshops, 264-270</i> </li>
                      </ul>
              </section>
        </div>
    </div>
</div>




</body>
</html>
