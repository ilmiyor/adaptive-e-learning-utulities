<?php
/* @var $this ConceptsController */
/* @var $model Concepts */

$this->breadcrumbs=array(
	'Concepts'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List Concepts', 'url'=>array('index')),
	array('label'=>'Manage Concepts', 'url'=>array('admin')),
);
?>

<h1>Create Concepts</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>