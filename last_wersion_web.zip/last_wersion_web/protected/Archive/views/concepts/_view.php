<?php
/* @var $this ConceptsController */
/* @var $data Concepts */
?>


<table class="view">
	<tr>
		<td>
			<b><?php echo CHtml::encode($data->getAttributeLabel('id')); ?>:</b>
			<?php echo CHtml::link(CHtml::encode($data->id), array('view', 'id'=>$data->id)); ?>
			<br/>
		</td>
		<td>
			<b><?php echo CHtml::encode($data->getAttributeLabel('topic_id')); ?>:</b>
			<?php echo CHtml::encode($data->topic_id); ?>
			<br />
		</td>
		<td>
			<b><?php echo CHtml::encode($data->getAttributeLabel('order')); ?>:</b>
			<?php echo CHtml::encode($data->order); ?>
			<br />
		</td>
		<td>
			<b><?php echo CHtml::encode($data->getAttributeLabel('title')); ?>:</b>
			<?php echo CHtml::encode($data->title); ?>
			<br />
		</td>
		<td>
			<b><?php echo CHtml::encode($data->getAttributeLabel('body')); ?>:</b>
			<?php echo CHtml::encode($data->body); ?>
			<br />
		</td>
		<td>
			<b><?php echo CHtml::encode($data->getAttributeLabel('vv')); ?>:</b>
			<?php echo CHtml::encode($data->vv); ?>
			<br />
		</td>
		<td>
			<b><?php echo CHtml::encode($data->getAttributeLabel('created_at')); ?>:</b>
			<?php echo CHtml::encode($data->created_at); ?>
			<br />
		</td>
</tr>
</table >
