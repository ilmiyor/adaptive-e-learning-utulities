<?php
/* @var $this ConceptsController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Concepts',
);

$this->menu=array(
	array('label'=>'Create Concepts', 'url'=>array('create')),
	array('label'=>'Manage Concepts', 'url'=>array('admin')),
);
?>

<h1>Concepts</h1>

<?php

// $sortedAr = array();


// ksort($arrayName);
// var_dump($arrayName);
// $dataProvider->pagination->pageSize = $dataProvider->totalItemCount;
// for ($i=0 ; $i < count($dataProvider->data)  ; $i++ ) {
// 	//var_dump($dataProvider->data[$i]->id, $dataProvider->data[$i]->topic_id);
// 		$sortedAr[$dataProvider->data[$i]->id] = $dataProvider->data[$i]->topic_id;
// // echo "<br>";
// }
// asort($sortedAr);
//
// foreach ($sortedAr as $key => $value) {
// 	echo($key.': '.$value);
// 	echo "<br>";
// }
// $sortById= array();
// for ($i=1; $i < count($dataProvider->data); $i++) {
// 		// echo $groupByTopic[$i];
// 		echo "$i. <br>";
// 	if (!empty($dataProvider->data[$i])) {
// 		var_dump($dataProvider->data[$i]->id);
// 		$sortById[$dataProvider->data[$i]->id][$i] = $dataProvider->data[$i];
// 		echo "==========================<br>";
// 		echo "<br>";
// 	}
// }
//
// ksort($sortById, SORT_NUMERIC);
// for ($i=1; $i < count($sortById); $i++) {
// 	if (!empty($sortById[$i])) {
// 		echo "$i. <br>";
// 		var_dump($sortById[$i]);
// 		echo "==========================<br>";
// 		echo "<br>";
// 	}
// }
// echo $sortById[2];

// $groupByTopic = array();
// foreach ($dataProvider->data as $key => $item) {
//    $groupByTopic[$item['id']][$key] = $item;
// }
// for ($i=1; $i < count($groupByTopic); $i++) {
// 		// echo $groupByTopic[$i];
// 	if (!empty($groupByTopic[$i])) {
// 		var_dump($groupByTopic[$i]);
// 		echo "<br>";
// 		echo "==========================<br>";
// 		echo "<br>";
// 	}
// }

// var_dump($groupByTopic[6]);

	// foreach ($groupByTopic as $key => $value) {
	// 	var_dump($groupByTopic[1][0]->body);
	// 	echo "<br>";
	// }
	// var_dump($model);
	// die();
	// var_dump($dataProvider->sort);
	// die();
	// $dataProvider->pagination->pageSize = $pages->pageSize;
	// echo($dataProvider->data[0]->body);

	$this->widget('zii.widgets.CListView', array(
	'itemsTagName' => 'Table',
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',

));

// echo "<pre>"; var_dump($dataProvider);
// die();
?>
