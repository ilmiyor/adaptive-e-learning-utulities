<?php
	if($this->style == 'vertical')
		$data_type = 'top';
	else
		$data_type = 'right';
?>

<script type="text/javascript">(function() {var script=document.createElement("script");script.type="text/javascript";script.async =true;script.src="//telegram.im/widget-button/index.php?id=@Lesslet";document.getElementsByTagName("head")[0].appendChild(script);})();</script>
<a href="https://telegram.im/@Lesslet" target="_blank" class="telegramim_button telegramim_shadow telegramim_pulse" style="font-size:26px;width:48px;background:#27A5E7;box-shadow:1px 1px 5px #27A5E7;color:#FFFFFF;border-radius:50px;" title=""><i></i></a>


<script type="IN/Share" data-url="<?php echo Yii::app()->createAbsoluteUrl(Yii::app()->request->url); ?>" data-counter="right"></script>
