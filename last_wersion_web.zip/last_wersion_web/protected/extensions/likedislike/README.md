yii-like-dislike
================

A simple yii extension to keep like dislike functionality