<?php
/* @var $this LessletController */
/* @var $dataProvider CActiveDataProvider */
echo($data);
?>
