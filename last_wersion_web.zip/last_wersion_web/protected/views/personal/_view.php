<?php
/* @var $this PersonalController */
/* @var $data ___ */
?>


						<div class="col-sm-4">
							<?php
							$myparam = array("concept_id"=>1, "concept_title"=>"", "params"=>$data->id);
							echo '<a href="'.Yii::app()->createUrl("lesslet/index",$myparam).'" style="text-decoration:none">';
							 ?>
								<div class="card  bg-light text-muted mb-3">
										<div class="card-body" style="padding: .10rem .25rem">
											<small>Ball: <b style="color:red; text-align:center">***<?=$this->getLessletScore($data->id)->summa?>***</b> </small><br>
											<small>Izoh: <?=$data->definition?></small><br>
											<small class="card-title">@<?=$data->id ?></small><br>
						      	</div>
								</div>
							</a>
						</div>
