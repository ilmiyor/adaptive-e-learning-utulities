<?php
/* @var $this LessletController */
/* @var $dataProvider CActiveDataProvider */
$data = array();
	foreach ($lessletActions as $key=> $lessletAction) {
			if ($conceptTitle=$this->getConceptName($conIds[$key]))
			{
				$lessletAction = ($lessletAction==null)?0:$lessletAction;
				$unagregatedLesslets = $this->highScoreLesslet($conIds[$key],$lessletAction);
				if (count($unagregatedLesslets)) {
					$menu[]=array(
						'label'=>substr($conceptTitle, 0, 10)."... ".count($unagregatedLesslets)."ta",
						'url'=>'#',
						'itemOptions'=>array('class'=>'nav-item'),
						'linkOptions'=>array('class'=>'nav-link disabled', 'tabindex'=>'-1', 'aria-disabled'=>'true'),
					);
				}

				?>

				<?php
				foreach ($unagregatedLesslets as $leskey => $value) {
					$data[$conIds[$key]][$leskey] = $value->getAttribute('id');
					$menu[]=array(
											'label'=>++$leskey.' - '.substr($value->getAttribute('definition'), 0, 12).'...',
											'url'=>array('lesslet/view','id'=>$value->getAttribute('id')),
											'itemOptions'=>array('class'=>'list-group-item'),
											'linkOptions'=>array('class'=>'nav-link'),
									);

					$this->menu = $menu;

				}
			}
	}
// print_r();exit;
// print_r($this->userActionScores());exit;
?>

<!-- Ribbon  -->
	<div class="row">
			<?php
			$activeTopics = array();
		foreach ($topics as $key => $topic){
			$nCons = $this->topicRibbon($topic['id']);
			$score = $nCons['scoreByTopic']?$nCons['scoreByTopic']/$nCons['lessIdsByConcept']:'0';
			if ($nCons['lessIdsByConcept']){
				$ribbonColor = 'bg-warning';
				$activeTopics[$topic['id']]=$topic['title'];
			}else {
				$ribbonColor = 'bg-light text-muted';
			}
			?>
			<div class="col-sm-2" style="padding:2.5px">
					<div class="card <?=$ribbonColor?> mb-3">
							<div class="card-body" style="padding: .10rem .25rem">
								<small> <b><?=++$key.'-'.substr($topic['title'], 0, 20)?></b> </small><br><br>
								<small class="card-title"><?=$score.' &nbsp;| '.$nCons['lessIdsByConcept'].'/'.$nCons['nCons']; ?></small>
			      	</div>
					</div>
			</div>
		<?php }//endForeach ?>
	</div>
	<!-- end of Ribbon -->
	<!-- *** Adaptive Lesslets for your preference *** -->
	<hr>
	<div class="row" <?=$this->isKnown?"":"hidden"?>>
		<div class="col-sm-2">
			<b class="small strong">Personalizatsiya qilingan Lessletlar</b>
		</div>
		<div class="col-sm-9">
			<?php
				echo "<div class='row'>";
						$this->widget('zii.widgets.CListView', array(
							'dataProvider'=>$dataProviderLS,
							'itemView'=>'_view',
							'template'=>"{items}",
							'itemsCssClass'=>'row',
							'pager' => array(
								'htmlOptions'=>array('class'=>'pagination pagination-sm justify-content-center', "hidden"=>"true"),
							),
						));
				echo "</div>";
			 ?>
		</div>
		<div class="col-sm-1"> <?php echo'<a href="'.Yii::app()->createUrl('personal/student',array('limit'=>-1, 'params'=>'ls')).'">Barchasi>></a>';?> </div>
	</div>
	<!-- *** High scored lesslets in your progress *** -->
	<hr>
	<div class="row">
		<div class="col-sm-2">
			<b class="small strong">Eng yuqori baholangan lessletlar</b>
		</div>
		<div class="col-sm-9">
			<?php
				echo "<div class='row'>";
						$this->widget('zii.widgets.CListView', array(
							'dataProvider'=>$dataProviderHigh,
							'itemView'=>'_view',
							'template'=>"{items}",
							'itemsCssClass'=>'row',
							'pager' => array(
								'htmlOptions'=>array('class'=>'pagination pagination-sm justify-content-center', "hidden"=>"true"),
							),
						));
				echo "</div>";
			 ?>
		</div>
		<div class="col-sm-1"> <?php echo'<a href="'.Yii::app()->createUrl('personal/student',array('limit'=>-1, 'params'=>'high')).'">Barchasi>></a>';?> </div>
	</div>
	<!-- *** Newly created lesslets in your progress *** -->
	<hr>
	<div class="row">
		<div class="col-sm-2">
			<b class="small strong">Yangi lessletlar</b>
		</div>
		<div class="col-sm-9">
			<?php
				echo "<div class='row'>";
						$this->widget('zii.widgets.CListView', array(
							'dataProvider'=>$dataProviderNew,
							'itemView'=>'_view',
							'template'=>"{items}",
							'itemsCssClass'=>'row',
							'pager' => array(
								'htmlOptions'=>array('class'=>'pagination pagination-sm justify-content-center', "hidden"=>"true"),
							),
						));
				echo "</div>";
			 ?>
		</div>
		<div class="col-sm-1"> <?php echo'<a href="'.Yii::app()->createUrl('personal/student',array('limit'=>-1, 'params'=>'new')).'">Barchasi>></a>';?> </div>
	</div>
<!-- Returns the user created lesslet(s), their scores and suggested lesslets -->
<hr>
	<div class="row">
		<div class="col-sm-2">
			<h4>Men yaratgan lessletlar</h4>
		</div>
		<div class="col-10">
			<div class="row">
				<?php
				$sortIt = $lessletActions;
				arsort($sortIt);

				// echo"<pre>";var_dump('sorted: ', $sortIt,'unsorted: ', $lessletActions);
				// exit;
			    foreach ($sortIt as $key=> $lessletAction) {
			      if ($conceptTitle=$this->getConceptName($conIds[$key]))
			      {
							$cardColor = ($lessletAction>0)?"text-white bg-success":(($lessletAction<0)?"text-white bg-danger":" bg-light");

							?>
							<div class="col-sm-6"> <div class="card <?= $cardColor ?> mb-4" style="max-width: 30rem;">
							  <div class="card-header " style="height: 2rem; padding-top:5px; text-align:right"><?php echo "<small class='sm'>@".$lesIds[$key]."; </small> "; echo " <img class='img'src='/images/svg/trans-star.svg' width='4%'> "; echo empty($lessletAction)?0:$lessletAction; ?></div>
							  <div class="card-body">
							    <h5 class="card-title"><?php echo substr($this->getTopic($conIds[$key]), 0, 25).'...'; ?></h5>
							    <p class="card-text"><?php echo $conceptTitle;
									$myparam = array("concept_id"=>1, "concept_title"=>"", "params"=>$lesIds[$key]);
									echo '<a class="btn btn-sm btn-primary" href="'.Yii::app()->createUrl("lesslet/index",$myparam).'">';
									echo "Ushbu lessletga murojat</a>";
									?></p>
							  </div>
								<div class="card-footer" style="height: 2rem; padding-top:5px;">
									<?php
									if (array_key_exists($conIds[$key], $data)) {
										echo "Havola: ";
										$myparam = array("concept_id"=>1, "concept_title"=>"", "params"=>implode(',',$data[$conIds[$key]]));
										echo '<a href="'.Yii::app()->createUrl("lesslet/index",$myparam).'" style="text-decoration:none; background:white">';
										foreach ($data[$conIds[$key]] as $i => $value) {
											// echo "<pre>";var_dump($data[$conIds[$key]]);exit;
										echo $value."; ";
										}
										echo " </a>";
									}
									// echo(array_key_exists($conIds[$key], $data)?count($data[$conIds[$key]]):'') ?>
								</div>
							</div></div>
							<?php

			        //   echo "<td><a href='".Yii::app()->createUrl('lesslet/view',array('id'=>$lesIds[$key]))."'>".$conceptTitle."</a></td>";
			        //   echo '<td>'.$lessletAction.'</td>';
			      }else $conceptTitle='';
			    }
			  ?>
			</div>
		</div>
</div>
