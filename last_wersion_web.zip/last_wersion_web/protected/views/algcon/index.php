<?php
/* @var $this AlgconController */
/* @var $dataProvider CActiveDataProvider */
//
// $this->breadcrumbs=array(
// 	'Algoritmlar',
// );
// $menu_topics['title'] = $this->curTopicId
 // echo "<pre>";print_r($topIds); echo "</pre>";
foreach ($topIds as $topId) {
	$menu_topics[]=array(
		'label'=>$topId->title,
		'url'=>array('algcon/index','id'=>$topId->id)
	);
	$this->menu_topics = $menu_topics;
}
//Object value with 3 highest scored lesslets (empty if there is none)
if ($model=$this->highScoreLesslet($dataProvider->keys[0])){
	foreach($model as $key => $lesslet){
		$this->menu[] = array(
			'definition'=>$lesslet['attributes']['definition'],
			'id'=>$lesslet['attributes']['id'],
		);
	}
}

$this->widget('zii.widgets.CListView', array(
'dataProvider'=>$dataProvider,
'itemView'=>'_view',
'template'=>"{pager}\n{items}",
'pager' => array(
	'htmlOptions'=>array('class'=>'pagination pagination-sm justify-content-center'),
	'internalPageCssClass'=>'page-item',
	'selectedPageCssClass'=>'page-item active',
	'datas'=>$pager,
	'header'=>'',
	'maxButtonCount'=>2,
	'prevPageLabel'=>'&laquo;',
	'nextPageLabel'=>'&raquo;',
	'firstPageLabel'=>'First',
	'lastPageLabel'=>'Last',
),))

// echo $dataProvider->data;
?>
