<?php
/* @var $this AlgconController */
/* @var $data Algcon */

?>
<div class="row">
	<div class="col-md-3">

		<?php
		foreach ($this->menu as $key => $value) {
				$myparam = array("concept_id"=>1, "concept_title"=>"", "params"=>$value['id']);
				echo '<a href="'.Yii::app()->createUrl("lesslet/index",$myparam).'" style="text-decoration:none">';
				 ?>
					<div class="card  bg-light text-muted mb-3">
							<div class="card-body" style="padding: .10rem .25rem">
									<small>Ball: <b style="color:red; text-align:center">***<?=$this->getLessletScore($value['id'])->summa?>***</b> </small><br>
									<small>Izoh: <?=$value['definition']?></small><br>
									<small class="card-title">@<?=$value['id'] ?></small><br>
							</div>
					</div>
				</a>
			<?php
		}
		?>
	</div>
	<div class="col-md-9">
		<div class="view">
			<p>
				<h1 style="margin-bottom:0;"><?php echo $data->title ?></h1>
				<small class="text-muted"><b>Muallif:</b> <cite>D.Ahmadaliev</cite> </small>
			</p>
			<?php echo $data->body ?> <br>

			| <a href="<?=Yii::app()->createUrl('lesslet/index',array('concept_id'=>$data->id, 'concept_title'=>$data->title, 'params'=>null))?>">
				 <img src="/images/lesslet-icon3.png" width=30> </a> |

			<?php echo CHtml::link(CHtml::encode('change'), array('update', 'id'=>$data->id),array('style'=>Yii::app()->user->isGuest?'display: none':'')); ?>
			<br />

		</div>
	</div>
</div>
