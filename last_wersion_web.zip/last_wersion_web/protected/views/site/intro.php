<?php
/* @var $this SiteController */
/* @var $model LoginForm */
/* @var $form CActiveForm  */

$this->pageTitle=Yii::app()->name . ' - Login';
$this->breadcrumbs=array(
	'Login',
);
?>
<div class="row justify-content-center">
	<div class="col-4">

		<h1 align='center'>Assalomu alaykum</h1>
		<?php var_dump(Yii::app()->user->Url); ?>
		<small class="text-muted">Agar bu birinchi tashrifingiz bo'lmasa tizimga <a href="<?=Yii::app()->user->isGuest?(Yii::app()->createUrl('site/login')):"#" ?>">shu joydan </a>kiring, aks holda quyidagi tizim haqida yo'riqnoma bilan tanishib chiqishingizni so'raymiz. </small>
	</div>
</div>
