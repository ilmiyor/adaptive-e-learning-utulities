<?php
/* @var $this SiteController */
/* @var $model LoginForm */
/* @var $form CActiveForm  */

$this->pageTitle=Yii::app()->name . ' - Login';
$this->breadcrumbs=array(
	'Login',
);
?>
<div class="row justify-content-center">
	<div class="col-4">

		<h1 align='center'>Login</h1>

		<small class="text-muted">Iltimos, tizimga kirish uchun login ma`lumotingizni kiriting:</small>

		<div class="form-signin">
		<?php $form=$this->beginWidget('CActiveForm', array(
			'id'=>'login-form',
			'enableClientValidation'=>true,
			'clientOptions'=>array(
				'validateOnSubmit'=>true,
			),
		)); ?>


				<?php echo $form->labelEx($model,'username', array('class'=>'sr-only')); ?>
				<?php echo $form->textField($model,'username', array('class'=>'form-control', 'placeholder'=>'Username')); ?>
				<?php echo $form->error($model,'username',array('class'=>'invalid-feedback')); ?>

				<?php echo $form->labelEx($model,'password',array('class'=>'sr-only')); ?>
				<?php echo $form->passwordField($model,'password',array('class'=>'form-control', 'placeholder'=>'Password')); ?>
				<?php echo $form->error($model,'password',array('class'=>'invalid-feedback')); ?>


				<?php echo $form->checkBox($model,'rememberMe',array('class'=>'checkbox')); ?>
				<?php echo $form->label($model,'rememberMe'); ?>
				<?php echo $form->error($model,'rememberMe',array('class'=>'invalid-feedback')); ?>

				<?php echo CHtml::submitButton('Login',array('class'=>'btn btn-lg btn-primary btn-block')); ?>

		<?php $this->endWidget(); ?>
		</div><!-- form -->
	</div>
</div>
