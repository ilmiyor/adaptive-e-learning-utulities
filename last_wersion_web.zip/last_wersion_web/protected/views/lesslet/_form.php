<?php
/* @var $this LessletController */
/* @var $model Lesslet */
/* @var $form CActiveForm */
?>
<div class="form">
<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'lesslet-form',
	// Please note: When you enable ajax validation, make sure the corresponding
	// controller action is handling ajax validation correctly.
	// There is a call to performAjaxValidation() commented in generated controller code.
	// See class documentation of CActiveForm for details on this.
	'enableAjaxValidation'=>false,
	'htmlOptions'=>array('enctype'=>'multipart/form-data'),// This is required for file upload
)); ?>

		<h1 style="color:red"><?php echo Yii::app()->user->getFlash('error'); ?></h1>
		<p class="note"> <span class="required">*</span> li joylar to'ldirilishi shart.</p>

		<?php echo $form->errorSummary($model,'Iltios, quyidagilarni kiriting!','',array('class'=>'invalid-feedback')); ?>
		<?php $conceptId =$model->concept_id==0?"":"id='$model->concept_id'"; ?>
			<div class="form-row">
				<div class="col-sm-1">
					<small class="text-muted"><?php echo $form->labelEx($model,'concept_id'); ?></small>
				</div>
				<div class="col-sm-8">
					<?php echo $form->dropDownList($model,'concept_id',CHtml::listData(Algcon::model()->findAll($model->concept_id==0?"":"id='$model->concept_id'"),'id','title'), array('class'=>'form-control-sm')); ?>
					<?php echo $form->error($model,'concept_id',array('class'=>'invalid-feedback')); ?>
				</div>
			</div>
			<div class="form-row">
					<div class="col-sm-1">
						<small class="text-muted"><?php echo $form->labelEx($model,'definition'); ?></small>
					</div>
					<div class="col-sm-8">
						<?php echo $form->textArea($model,'definition',array('rows'=>3, 'cols'=>5,'class'=>'form-control')); ?>
						<?php echo $form->error($model,'definition', array('class'=>'invalid-feedback')); ?>
					</div>
			</div>
			<div class="form-row">
				<div class="col-sm-1">
					<small class="text-muted"><?php echo $form->labelEx($model,'example'); ?></small>
				</div>
				<div class="col-sm-8">
					<?php echo $form->textArea($model,'example',array('rows'=>3, 'cols'=>5,'class'=>'form-control')); ?>
					<?php echo $form->error($model,'example',array('class'=>'invalid-feedback')); ?>
				</div>
				<div class="col-sm-3">
					<small class="text-muted"><?php echo $form->labelEx($model,'image_example'); ?></small>
					<?php echo $form->fileField($model,'image_example',array('id'=>'file', 'class'=>'form-control-file')); ?>
					<?php echo $form->error($model,'image_example',array('class'=>'invalid-feedback')); ?>
				</div>
		</div>
		<div class="form-row">
			<div class="col-sm-1">
				<small class="text-muted"><?php echo $form->labelEx($model,'test'); ?></small>
			</div>
			<div class="col-sm-8">
				<?php echo $form->textArea($model,'test',array('rows'=>3, 'cols'=>5,'class'=>'form-control')); ?>
				<?php echo $form->error($model,'test',array('class'=>'invalid-feedback')); ?>
			</div>
		</div>
		<div class="form-row">
			<div class="col-sm-1">
				<small class="text-muted"><?php echo $form->labelEx($model,'correct_answer'); ?></small>
			</div>
			<div class="col-sm-8">
				<?php echo $form->textField($model,'correct_answer',array('size'=>45,'maxlength'=>45),array('class'=>'form-control')); ?>
				<?php echo $form->error($model,'correct_answer',array('class'=>'invalid-feedback')); ?>
			</div>
		</div>
		
<!-- <?php // if (Yii::app()->user->isGuest): ?>

	<?php  // if(CCaptcha::checkRequirements()): ?>
	<div class="form-group">
		<?php // echo $form->labelEx($model,'verifyCode'); ?>
		<div>
		<?php // $this->widget('CCaptcha'); ?>
		<?php  // echo $form->textField($model,'verifyCode'); ?>
		</div>
		<div class="hint">Please enter the letters as they are shown in the image above.
		<br/>Letters are not case-sensitive.</div>
		<?php //  echo $form->error($model,'verifyCode'); ?>
	</div>
	<?php     // endif; ?>

<?php // endif; ?> -->
<div class="form-row">
	<?php echo CHtml::submitButton($model->isNewRecord ? 'Yaratish' : 'Saqlash', array('class'=>'btn btn-primary')); ?>
</div>
<?php $this->endWidget(); ?>
</div>
<!-- form -->
