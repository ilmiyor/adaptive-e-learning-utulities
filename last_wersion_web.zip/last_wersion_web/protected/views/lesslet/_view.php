<?php
/* @var $this LessletController */
/* @var $data Lesslet */
$model=$this->getLessletScore($data->id);
if (is_null($model->summa)) {
	$score = 0;
}
else {
	$score = $model->summa;
}

if (!empty($data->image_example)) {
	$my_image = "<img width='40%' src='http://img.doniyorbek.com:1111/images/lesslet_images/".$data->image_example."'>";
	var_dump($my_image);exit();
}else {
	$my_image='';
}

?>

		<div class="col-12">
			<div class="card bg-light mb-3" style="max-width:100%;">
			  <!-- <div class="card-header">Takrorlanuvchi algoritmlar</div> -->
			  <div class="card-body">
					<?php $this->shareCont['def'] = $data->definition; ?>
					<h5 class="card-title"><?php echo CHtml::decode($this->lessletData['concept_title']); ?></h5>
					<p class="card-text"><b><?php echo CHtml::encode($data->getAttributeLabel('Izoh')); ?>:</b> <?php echo CHtml::decode($data->definition); ?></p>
					<p class="card-text"><b><?php echo CHtml::encode($data->getAttributeLabel('Misol')); ?>:</b><?php echo CHtml::decode($data->example.$my_image); ?>
					<p class="card-text"><b><?php echo CHtml::encode($data->getAttributeLabel('Test')); ?>:</b><?php echo CHtml::decode($data->test); ?>
					<p class="card-text"><b><?php echo CHtml::encode($data->getAttributeLabel('Javob')); ?>:</b><?php echo CHtml::decode($data->correct_answer); ?>
			  </div>
				<div class="card-footer">
					<small class="text-muted">
					<div class="row">
					<?php
						if ($valid=$this->getLesConIds()['lesIds']) {
							$canVote=in_array($data->id, $valid)?false:true;
						}elseif (empty($valid)) {
							$canVote = true;
						}else $canVote=false;

						if($canVote)
						{
							echo CHtml::ajaxLink(
							"<img src='/images/ico_plus.svg' width='10px'>",          				 // the link body (it will NOT be HTML-encoded.)
							array("lesslet/ajax",
									"user_id"=>Yii::app()->user->getId(),
									"lesslet_id"=>$data->id,
									"score"=>"plus",
								 ), //the URL for the AJAX request. If empty, it is assumed to be the current URL.
							 array(
 									"update"=>"#req_res".$data->id,
								));
						}else echo '<img src="/images/ico_cross.svg" width="10px">';
						echo '<div id="req_res'.$data->id.'">'.$score.'</div>';
						if($canVote)
						{echo CHtml::ajaxLink(
							'<img src="/images/ico_minus.svg" width="10px">',          				 // the link body (it will NOT be HTML-encoded.)
							array('lesslet/ajax',
							'user_id'=>Yii::app()->user->getId(),
							'lesslet_id'=>$data->id,
							'score'=>'minus',
							), // the URL for the AJAX request. If empty, it is assumed to be the current URL.
							array(
									'update'=>'#req_res'.$data->id,
							)
						);
					}else {echo '<img src="/images/ico_cross.svg" width="10px">';}
					$this->shareCont['score'] = $score;
					 ?>

					 </small>
				</div>
				</div>
			</div>
			<div>
				<?php
				// $this->widget('application.extensions.SocialShareButton.SocialShareButton', array(
				// 	'style'=>'horizontal',
				// 	'networks' => array('telegram'),
				// 	'data_via'=>'rohisuthar', //twitter username (for twitter only, if exists else leave empty)
				// ));
				?>
			</div>
	</div>

<div class="view">


</div>
