<?php
/* @var $this LessletController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Lessletlar',
);

$this->menu=array(
	array('label'=>'Yangi Lesslet', 'url'=>array('create', 'cid'=>$lessletData['concept_id'])),
	array('label'=>'Manage Lesslet', 'url'=>array('admin'), 'visible'=>!Yii::app()->user->isGuest),
);
$this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
	'itemsCssClass'=>'row',
	'template'=>"{pager}\n{items}\n{pager}",
	'pager' => array(
		'htmlOptions'=>array('class'=>'pagination pagination-sm justify-content-center'),
		'internalPageCssClass'=>'page-item',
		'selectedPageCssClass'=>'page-item active',
		'header'=>'',
		'maxButtonCount'=>2,
		'prevPageLabel'=>'&lt;',
		'nextPageLabel'=>' &gt;',
		'firstPageLabel'=>'&lt;&lt;',
		'lastPageLabel'=>' &gt;&gt;',
	),
	'emptyText' => "<b>".$lessletData['concept_title']."</b>bo`yicha lessletlar hali yo`q, Siz yaratishingiz mumkin",
)); ?>
