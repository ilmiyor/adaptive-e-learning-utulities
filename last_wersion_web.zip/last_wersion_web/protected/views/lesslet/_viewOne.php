<?php
/* @var $this LessletController */
/* @var $data Lesslet */

$criteria = new CDbCriteria();
$criteria->select="sum(action) as summa";
$criteria->condition = "lesslet_id=:lid";
$criteria->params = array('lid'=>$data->id);
$model=Actions::model()->find($criteria);
if (is_null($model->summa)) {
	$score = 0;
}
else {
	$score = $model->summa;
}
?>
<div class="view">
	<b><?php echo CHtml::encode($data->getAttributeLabel('Tushuncha')); ?>:</b>
	<?php echo CHtml::decode($this->lessletData['concept_title']); ?>
	<hr>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('Izoh')); ?>:</b>
	<?php echo CHtml::decode($data->definition); ?>
	<br />
	<hr>

	<?php
	if (!empty($data->image_example)) {
		$my_image = "<img width='40%' src='http://img.doniyorbek.com:1111/images/".$data->image_example."'>";
	}else {
		$my_image='';
	}
	 ?>
	<b><?php echo CHtml::encode($data->getAttributeLabel('Misol')); ?>:</b>
	<?php echo CHtml::decode($data->example.$my_image); ?>
	<br />
	<hr>

	<b><?php echo CHtml::encode($data->getAttributeLabel('image_example')); ?>:</b>
	<?php echo CHtml::decode($data->image_example); ?>
	<br />
	<hr>


	<b><?php echo CHtml::encode($data->getAttributeLabel('Test')); ?>:</b>
	<?php echo CHtml::decode($data->test); ?>
	<br />
	<hr>

	<b><?php echo CHtml::encode($data->getAttributeLabel('Javob')); ?>:</b>
	<?php echo CHtml::decode($data->correct_answer); ?>

	<hr>
<?php
	if ($this->getLesConIds()['lesIds']) {
		$canUpvote=in_array($data->id, $this->getLesConIds()['lesIds'])?false:true;
	}elseif (empty($this->getLesConIds()['lesIds'])) {
		$canUpvote = true;
	}else $canUpvote=false;
 ?>
	<br/>

	<?php
	if($canUpvote)
	{echo CHtml::ajaxLink(
		'<img src="/images/ico_plus.svg" width="10px">',          				 // the link body (it will NOT be HTML-encoded.)
		array('lesslet/ajax',
				'user_id'=>Yii::app()->user->getId(),
				'lesslet_id'=>$data->id,
				'score'=>'plus',
			 ), // the URL for the AJAX request. If empty, it is assumed to be the current URL.
		array(
				'update'=>'#req_res'.$data->id,
		)
	);
	}else echo '<img src="/images/ico_cross.svg" width="10px">';
	// echo "<div id=req_res".$data->id.">".$data->score."</div>";
	echo '<div id="req_res'.$data->id.'">'.$score.'</div>';
	if($canUpvote)
	{echo CHtml::ajaxLink(
		'<img src="/images/ico_minus.svg" width="10px">',          				 // the link body (it will NOT be HTML-encoded.)
		array('lesslet/ajax',
		'user_id'=>Yii::app()->user->getId(),
		'lesslet_id'=>$data->id,
		'score'=>'minus',

		), // the URL for the AJAX request. If empty, it is assumed to be the current URL.
		array(
				'update'=>'#req_res'.$data->id,
		)
	);
}else echo '<img src="/images/ico_cross.svg" width="10px">'

	/*
	<b><?php echo CHtml::encode($data->getAttributeLabel('id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->id), array('view', 'id'=>$data->id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('user_id')); ?>:</b>
	<?php echo CHtml::encode($data->user_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('concept_id')); ?>:</b>
	<?php echo CHtml::encode($data->concept_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('definition')); ?>:</b>
	<?php echo CHtml::encode($data->definition); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('example')); ?>:</b>
	<?php echo CHtml::encode($data->example); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('test')); ?>:</b>
	<?php echo CHtml::encode($data->test); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('correct_answer')); ?>:</b>
	<?php echo CHtml::encode($data->correct_answer); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('score')); ?>:</b>
	<?php echo CHtml::encode($data->score); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('created_at')); ?>:</b>
	<?php echo CHtml::encode($data->created_at); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('updated_at')); ?>:</b>
	<?php echo CHtml::encode($data->updated_at); ?>
	<br />

	*/ ?>

</div>
