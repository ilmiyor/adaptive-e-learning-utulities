<?php /* @var $this Controller */ ?>
<!DOCTYPE html>
<html class="h-100">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta name="language" content="en">

	<!-- blueprint CSS framework -->
	<!-- <link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/css/screen.css" media="screen, projection">
	<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/css/print.css" media="print"> -->
	<!--[if lt IE 8]>
	<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/css/ie.css" media="screen, projection">
	<![endif]-->

	<!-- <link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/css/main.css">
	<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/css/form.css">
	<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/css/tables.css"> -->
	<!-- Required meta tags -->
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

	<title><?php echo CHtml::encode($this->PageTitle); ?></title>
</head>

<body class="d-flex flex-column h-100">
<div class="container" id="page">
<div class="row-fluid">
	<div id="mainmenu">
		<div class="row">
			<div class="col-sm-8">
				<div id="header">
					<div id="logo">
						<a href="<?=Yii::app()->createUrl('algcon/index')?>"><img src="/images/lesslet-icon3.png" width="8%"></a>
					</div>
				</div><!-- header -->
			</div>
			<div class="col-sm-4">
				<?php
				$this->widget('zii.widgets.CMenu',
					array(
						'htmlOptions'=>array('class'=>'nav nav-pills'),
						'items'=>array(
							array(
							'label'=>'Login',
							'url'=>array('/site/login'),
							'visible'=>Yii::app()->user->isGuest,
							'linkOptions'=>array('class'=>'nav-link'),
							'itemOptions'=>array('class'=>'nav-item', 'style'=>'float:right'),
							),
							array('label'=>"Logout (".Yii::app()->user->name.")",
								'url'=>array('/site/logout'),
								'visible'=>!Yii::app()->user->isGuest,
								'linkOptions'=>array('class'=>'nav-link'),
								'itemOptions'=>array('class'=>'nav-item', 'style'=>'float:right')
							),
						),
					),
				);
			?>
			</div>
		</div>
	</div><!-- mainmenu -->
	<hr>
</div>
<div class="row-fluid">

	<?php echo $content; ?>
</div>
<div class="clear"></div>
</div>
		<footer class="footer mt-auto py-3" id="footer" style="text-align:center">
		<small class="container text-muted">
			&copy; <?php echo date('Y'); ?> by Doniyorbek Ahmadaliev.<br/>
		 Barcha huquqlar himoyalangan.<br/>
	 </small>
		</footer><!-- footer -->


		<!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
		<!-- *****jQuery slim using is causing problem on ajax function with voting. That's why I commented out **** -->
		<!-- <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script> -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>
