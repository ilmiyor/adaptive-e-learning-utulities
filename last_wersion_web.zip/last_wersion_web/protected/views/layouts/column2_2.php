<?php /* @var $this Controller */ ?>
<?php $this->beginContent('//layouts/main'); ?>
<div class="row justify-content-start">
			<div class="col-md-1">
				<a class="btn btn-outline-secondary" style="padding:0px;" href="<?=Yii::app()->createUrl('lesslet/create') ?>"><img src="/images/icons/blueprint.svg" width="60%"></a>
			</div>
			<div class="col-md-3">
				<a class="btn btn-outline-secondary" href="<?=Yii::app()->user->isGuest?(Yii::app()->createUrl('/site/login')):(Yii::app()->createUrl('personal/student')) ?>" >
					<?php if (Yii::app()->user->isGuest): ?>
						<small>Iltimos, avval <b>Login</b>, <br>so'ng adaptive ni yoqing </small>
					<?php else: ?>
						<?php echo(Yii::app()->user->isGuest?'':"L:".round($this->score(),2)." | C: ".count(array_unique($this->getLesConIds()['conIds']))."\n <br>Shahsiy platforma");  //echo "<pre>"; var_dump(); exit; ?>
					<?php endif; ?>
				</a>
			</div>
			<div class="col-md-5">
				<a class="nav-link btn-primary dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false" <?php echo empty($this->menu_topics)?'hidden':'' ?>>Mavzular: <?=$this->getTopic(1,$this->curTopicId)?></a>
				<div class="dropdown-menu" <?php echo empty($this->menu_topics)?'hidden':'' ?>>
					<?php foreach ($this->menu_topics as $key => $value): ?>
						<a class="dropdown-item" href="<?=Yii::app()->createUrl('algcon/index',array('id'=>$value['url']['id'])) ?>"><?=$value['label']?></a>
					<?php endforeach; ?>
				</div>
			</div>

</div>
	<!-- <div class="col-sm-9"> -->
		<div id="content">
				<?php echo $content; ?>
		</div><!-- content -->
	<!-- </div> -->

<?php $this->endContent(); ?>
